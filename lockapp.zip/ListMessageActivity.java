package com.lockapp;

import java.util.ArrayList;
import java.util.List;

import com.lockapp.adapter.ListMessageAdapter;
import com.lockapp.entity.Mensagem;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

public class ListMessageActivity extends Activity {

	private ListView listViewMensagem;
	private ListMessageAdapter adapter;
	private List<Mensagem> listMensagem;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_list_mensagens);
		listViewMensagem = (ListView) findViewById(R.id.listViewMensagens);
		new ProcessaMensagens(this).execute();
	}

	public class ProcessaMensagens extends AsyncTask<Void, Void, Void> {

		private Context context;
		private ProgressDialog dialog;
		public ProcessaMensagens(Context context) {
			this.context = context;
		}

		@Override
		protected void onPreExecute() {
			dialog = new ProgressDialog(context);
			dialog.setTitle("ColorLock");
			dialog.setMessage("��ٷ��ּ���");
			dialog.setCancelable(false);
			dialog.show();
		}

		@Override
		protected Void doInBackground(Void... params) {
			listMensagem = new ArrayList<Mensagem>();
			Uri message = Uri.parse("content://sms/");
			ContentResolver cr = getContentResolver();

			Cursor cursor = cr.query(message, null, null, null, null);
			startManagingCursor(cursor);

			for (int i = 0; i < cursor.getCount(); i++) {
				cursor.moveToPosition(i);
				Mensagem mensagem = new Mensagem();
				mensagem.setId(cursor.getString(cursor
						.getColumnIndexOrThrow("_id")));
				mensagem.setEndereco(cursor.getString(cursor
						.getColumnIndexOrThrow("address")));
				mensagem.setMensagem(cursor.getString(cursor
						.getColumnIndexOrThrow("body")));
				mensagem.setEstadoLeitura(cursor.getString(cursor
						.getColumnIndex("read")));
				mensagem.setData(cursor.getString(cursor
						.getColumnIndexOrThrow("date")));
				if (cursor.getString(cursor.getColumnIndexOrThrow("type"))
						.contains("1")) {
					mensagem.setFolderName("����");
				} else {
					mensagem.setFolderName("����");
				}
				listMensagem.add(mensagem);
			}
			cursor.close();
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			adapter = new ListMessageAdapter(context, listMensagem);
			listViewMensagem.setAdapter(adapter);
			adapter.notifyDataSetChanged();
			dialog.dismiss();
		}
	}
}