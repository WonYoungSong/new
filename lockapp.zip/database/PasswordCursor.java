package com.lockapp.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteQuery;

public class PasswordCursor extends SQLiteCursor {

	public static final String QUERY = "select * from password";

	public PasswordCursor(SQLiteDatabase db, SQLiteCursorDriver driver,
			String editTable, SQLiteQuery query) {
		super(db, driver, editTable, query);
	}

	public static class Factory implements CursorFactory {

		@Override
		public Cursor newCursor(SQLiteDatabase db,
				SQLiteCursorDriver masterQuery, String editTable,
				SQLiteQuery query) {
			return new PasswordCursor(db, masterQuery, editTable, query);
		}
	}

	public int getIdPassword() {
		return getInt(getColumnIndexOrThrow("idpassword"));
	}

	public int getDigitFirst() {
		return getInt(getColumnIndexOrThrow("firstpassword"));
	}

	public int getDigitSecond() {
		return getInt(getColumnIndexOrThrow("secondpassword"));
	}

	public int getDigitThird() {
		return getInt(getColumnIndexOrThrow("thirdpassword"));
	}

	public int getDigitLast() {
		return getInt(getColumnIndexOrThrow("lastpassword"));
	}

	public int getColorFirst() {
		return getInt(getColumnIndexOrThrow("firstpasswordcolor"));
	}

	public int getColorSecond() {
		return getInt(getColumnIndexOrThrow("secondpasswordcolor"));
	}

	public int getColorThird() {
		return getInt(getColumnIndexOrThrow("thirdpasswordcolor"));
	}

	public int getColorLast() {
		return getInt(getColumnIndexOrThrow("lastpasswordcolor"));
	}

	public int getAuthenticationCount() {
		return getInt(getColumnIndexOrThrow("authenticationcount"));
	}

	public int getLockServiceOn() {
		return getInt(getColumnIndexOrThrow("lockserviceon"));
	}
}