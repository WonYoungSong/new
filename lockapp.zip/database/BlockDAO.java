package com.lockapp.database;

import com.lockapp.entity.Block;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

public class BlockDAO extends LockAppDatabase {

	public BlockDAO(Context context) {
		super(context);
	}

	public BlockCursor getAll(){
		SQLiteDatabase dataBase = getReadableDatabase();
		BlockCursor cursor = (BlockCursor) dataBase.rawQueryWithFactory(
				new BlockCursor.Factory(), BlockCursor.QUERY, null, null);
		cursor.moveToFirst();
		for (int i = 0; i < cursor.getCount(); i++) {
			cursor.moveToPosition(i);
		}
		return cursor;
	}

	public BlockCursor getBlockId(int id){
		SQLiteDatabase dataBase = getReadableDatabase();
		BlockCursor cursor = (BlockCursor) dataBase.
				rawQueryWithFactory(new BlockCursor.Factory(), "select * from block where idblock = "+id, null, null);
		cursor.moveToFirst();
		return cursor;
	}
	
	public void insert(Block block) {

		String sql = "insert or ignore into block (nameapp, packageapp, iconapp, library) values (?,?,?,?)";
		Object[] obj = new Object[] { block.getNameApp(),
				block.getPackageApp(), block.getArrayImg(), block.getLibrary() };
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("ERROR ON LOCKED APP INSERT", e.getMessage());
		}
	}

	public void delete(Block block){
		String sql = "delete from block where nameapp = ?";
		Object[] obj = new Object[]{ 
				block.getNameApp()
		};
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("ERROR ON LOCKED APP DELETE", e.getMessage());
		}
	}
	
	public void update(Block block){
		String sql = "update block set library = ? where idblock = ?";
		Object[] obj = new Object[]{block.getLibrary(), block.getIdBlock()};
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("ERROR ON LOCKED APP UPDATE", e.getMessage());
		}
	}	
}