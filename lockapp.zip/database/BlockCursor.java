package com.lockapp.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteQuery;

public class BlockCursor extends SQLiteCursor {

	public static final String QUERY = "SELECT * FROM block";

	public BlockCursor(SQLiteDatabase db, SQLiteCursorDriver driver,
			String editTable, SQLiteQuery query) {
		super(db, driver, editTable, query);
	}

	public static class Factory implements CursorFactory {
		@Override
		public Cursor newCursor(SQLiteDatabase db,
				SQLiteCursorDriver masterQuery, String editTable,
				SQLiteQuery query) {
			return new BlockCursor(db, masterQuery, editTable, query);
		}
	}

	public int getIdBlock() {
		return getInt(getColumnIndexOrThrow("idblock"));
	}

	public String getNameApp() {
		return getString(getColumnIndexOrThrow("nameapp"));
	}

	public String getPackageApp() {
		return getString(getColumnIndexOrThrow("packageapp"));
	}

	public byte[] getImgApp() {
		return getBlob(getColumnIndexOrThrow("iconapp"));
	}

	public int getLibrary() {
		return getInt(getColumnIndexOrThrow("library"));
	}
}