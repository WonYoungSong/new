package com.lockapp.database;

import com.lockapp.entity.Password;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

public class PasswordDB extends LockAppDatabase {

	public PasswordDB(Context context) {
		super(context);
	}

	public PasswordCursor getPassword() {
		SQLiteDatabase dataBase = getReadableDatabase();
		PasswordCursor cursor = (PasswordCursor) dataBase.rawQueryWithFactory(
				new PasswordCursor.Factory(), PasswordCursor.QUERY, null, null);
		cursor.moveToFirst();
		return cursor;
	}

	public void insert(Password password) {
		String sql = "insert into password (idpassword, firstpassword, secondpassword, thirdpassword, lastpassword, "
				+ "firstpasswordcolor, secondpasswordcolor, thirdpasswordcolor, lastpasswordcolor,"
				+ " authenticationcount, lockserviceon) values (?,?,?,?,?,?,?,?,?,?,?)";
		Object[] obj = new Object[] { password.getIdPassword(),
				password.getFirstPassword(), password.getSecondPassword(),
				password.getThirdPassword(), password.getLastPassword(),

				password.getFirstPasswordColor(),
				password.getSecondPasswordColor(),
				password.getThirdPasswordColor(),
				password.getLastPasswordColor(),
				password.getAuthenticationCount(), 1 };
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("�߸������ϴ�.", e.getMessage());
		}
	}

	public void updateCount(Password password) {
		String sql = "update password set authenticationcount = ? where idpassword = 1";
		Object[] obj = new Object[] { password.getAuthenticationCount() };
		// String str = password.getAuthenticationCount();
		Log.v("PasswordDB", "count : " + password.getAuthenticationCount());
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("�߸� �����ϴ�.", e.getMessage());
		}
	}

	public void updateLockServiceOn() {
		String sql = "update password set lockserviceon = ? ";
		Object[] obj = new Object[] { 1	};
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("�߸� �����ϴ�.", e.getMessage());
		}
	}

	public void updateLockServiceOff() {
		String sql = "update password set lockserviceon = ? ";
		Object[] obj = new Object[] { 0	};
		try {
			getWritableDatabase().execSQL(sql, obj);
		} catch (Exception e) {
			Log.e("�߸� �����ϴ�.", e.getMessage());
		}
	}

	public void update(Password password) {
		String sql = "update password set firstpassword = ?, secondpassword = ?, thirdpassword = ?, lastpassword = ?, firstpasswordcolor = ?, secondpasswordcolor = ?, thirdpasswordcolor = ?, lastpasswordcolor = ? where idpassword = 1";
		Object[] obj = new Object[] { password.getFirstPassword(),
				password.getSecondPassword(), password.getThirdPassword(),
				password.getLastPassword(), password.getFirstPasswordColor(),
				password.getSecondPasswordColor(),
				password.getThirdPasswordColor(),
				password.getLastPasswordColor() };
		String Tag = "PasswordDB";
		Log.v(Tag, "firstpassword : " + password.getFirstPassword());
		Log.v(Tag, "secondpassword : " + password.getSecondPassword());
		Log.v(Tag, "thirdpassword : " + password.getThirdPassword());
		Log.v(Tag, "lastpassword : " + password.getLastPassword());

		Log.v(Tag, "firstpasswordcolor : " + password.getFirstPasswordColor());
		Log.v(Tag, "secondpasswordcolor : " + password.getSecondPasswordColor());
		Log.v(Tag, "thirdpasswordcolor : " + password.getThirdPasswordColor());
		Log.v(Tag, "lastpasswordcolor : " + password.getLastPasswordColor());

		try {
			getWritableDatabase().execSQL(sql, obj);

		} catch (Exception e) {
			Log.v("PasswordDB", "update error");
		}
	}

	public void delete() {
		String sql = "delete from password where idpassword = 1";
		try {
			getWritableDatabase().execSQL(sql);
		} catch (Exception e) {
			Log.v("PasswordDB", "DELETE ERROR");
		}
	}

}