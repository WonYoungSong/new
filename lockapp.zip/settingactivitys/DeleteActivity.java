package com.lockapp.settingactivitys;

import com.lockapp.R;
import com.lockapp.database.PasswordCursor;
import com.lockapp.database.PasswordDB;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class DeleteActivity extends Activity {
	private Button delete_OK_Button;
	private Button delete_NO_Button;

	private PasswordDB dao;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_delete_password);
		delete_OK_Button = (Button) findViewById(R.id.delete_OK_Button);
		delete_NO_Button = (Button) findViewById(R.id.delete_NO_Button);

		dao = new PasswordDB(this);

		delete_OK_Button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(v.getContext(), "�������ϴ�~", Toast.LENGTH_SHORT).show();
				dao.delete();
				finish();
			}
		});
		delete_NO_Button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
}
