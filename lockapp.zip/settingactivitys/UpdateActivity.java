package com.lockapp.settingactivitys;

import java.util.Random;

import com.lockapp.MainActivity;
import com.lockapp.R;
import com.lockapp.database.PasswordCursor;
import com.lockapp.database.PasswordDB;
import com.lockapp.entity.Password;
import com.lockapp.settingactivitys.CameraActivity;
import com.lockapp.settingactivitys.DeleteActivity;

import android.R.color;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class UpdateActivity extends Activity {
	ImageView imgView1;
	ImageView imgView2;
	ImageView imgView3;

	String str;
	int stringPointer = 0;
	int colorCount = 0;

	String[] passwordDigit;
	int[] passwordColor;

	EditText password_EditText;
	int random1;
	int random2;
	int random3;
	int[] drawableImage;

	private int authenticationCount = 0;

	private void setPassword(int number) {
		if (stringPointer < 4) {
			colorCount++;
			passwordDigit[stringPointer] = Integer.toString(number);
			passwordColor[stringPointer] = colorCount;
		}
	}

	private int makePassword(int color) {

		int num = 0;
		int tempColor = color % 3;
		if (tempColor == 1) {
			num = random1;
		} else if (tempColor == 2) {
			num = random2;
		} else {
			num = random3;
		}
		return num;
	}

	private Button.OnClickListener btnClickListener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {

			switch (v.getId()) {
			case R.id.button11:
	
				Toast.makeText(v.getContext(), "0", Toast.LENGTH_SHORT).show();
				str += "0";
				password_EditText.setText(str);
				setPassword(0);
				break;
			case R.id.button1:

				Toast.makeText(v.getContext(), "1", Toast.LENGTH_SHORT).show();
				str += "1";
				password_EditText.setText(str);
				setPassword(1);
				break;
			case R.id.button2:
			
				Toast.makeText(v.getContext(), "2", Toast.LENGTH_SHORT).show();
				str += "2";
				password_EditText.setText(str);
				setPassword(2);
				break;
			case R.id.button3:
		
				Toast.makeText(v.getContext(), "3", Toast.LENGTH_SHORT).show();
				str += "3";
				password_EditText.setText(str);
				setPassword(3);
				break;
			case R.id.button4:
				
				Toast.makeText(v.getContext(), "4", Toast.LENGTH_SHORT).show();
				str += "4";
				password_EditText.setText(str);
				setPassword(4);
				break;
			case R.id.button5:
		
				Toast.makeText(v.getContext(), "5", Toast.LENGTH_SHORT).show();
				str += "5";
				password_EditText.setText(str);
				setPassword(5);
				break;
			case R.id.button6:
			
				Toast.makeText(v.getContext(), "6", Toast.LENGTH_SHORT).show();
				str += "6";
				password_EditText.setText(str);
				setPassword(6);
				break;
			case R.id.button7:
		
				Toast.makeText(v.getContext(), "7", Toast.LENGTH_SHORT).show();
				str += "7";
				password_EditText.setText(str);
				setPassword(7);
				break;
			case R.id.button8:
			
				Toast.makeText(v.getContext(), "8", Toast.LENGTH_SHORT).show();
				str += "8";
				password_EditText.setText(str);
				setPassword(8);
				break;
			case R.id.button9:
		
				Toast.makeText(v.getContext(), "9", Toast.LENGTH_SHORT).show();
				str += "9";
				password_EditText.setText(str);
				setPassword(9);
				break;
			case R.id.button10:

				Toast.makeText(v.getContext(), "Next", Toast.LENGTH_SHORT)
						.show();
				str += "";
				colorCount = 0;

				if (stringPointer < 4) {
					stringPointer++;
				}
				break;
			case R.id.button12:

				Toast.makeText(v.getContext(), "Finish", Toast.LENGTH_SHORT)
						.show();

				if (passwordDigit[0] != null && passwordDigit[1] != null
						&& passwordDigit[2] != null && passwordDigit[3] != null
						&& passwordColor[0] != 0 && passwordColor[1] != 0
						&& passwordColor[2] != 0 && passwordColor[3] != 0) {

					Password password = new Password();
					password.setIdPassword(1);
					password.setFirstPassword(Integer
							.parseInt(passwordDigit[0]));
					password.setSecondPassword(Integer
							.parseInt(passwordDigit[1]));
					password.setThirdPassword(Integer
							.parseInt(passwordDigit[2]));
					password.setLastPassword(Integer.parseInt(passwordDigit[3]));
					password.setFirstPasswordColor(makePassword(passwordColor[0]));
					password.setSecondPasswordColor(makePassword(passwordColor[1]));
					password.setThirdPasswordColor(makePassword(passwordColor[2]));
					password.setLastPasswordColor(makePassword(passwordColor[3]));
					password.setAuthenticationCount(3);
					password.setLockServiceOn(1);

					dao.insert(password);

					startActivity(new Intent(UpdateActivity.this,MainActivity.class));
					finish();
				}
				break;
			case R.id.button13:

				Toast.makeText(v.getContext(), "Reset", Toast.LENGTH_SHORT)
						.show();
				str = "";
				password_EditText.setText(str);
				colorCount = 0;
				stringPointer = 0;
				break;

			}
		}
	};

	Button[] buttonNumber;
	Button finishButton;
	Button nextButton;
	Button resetButton;

	PasswordDB dao;
	PasswordCursor passwordCursor;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_password);
		dao = new PasswordDB(this);
		passwordDigit = new String[4];
		passwordColor = new int[4];
		random1 = (int) (Math.random() * 3) + 1;
		random2 = (int) (Math.random() * 3) + 1;

		while (random1 == random2) {
			random2 = (int) (Math.random() * 3) + 1;
		}
		random3 = (int) (Math.random() * 3) + 1;
		while (random1 == random3 || random2 == random3) {
			random3 = (int) (Math.random() * 3) + 1;
		}

		str = "";

		imgView1 = (ImageView) findViewById(R.id.imgview1);
		imgView2 = (ImageView) findViewById(R.id.imgview2);
		imgView3 = (ImageView) findViewById(R.id.imgview3);

		buttonNumber = new Button[10];
		buttonNumber[0] = (Button) findViewById(R.id.button11);
		buttonNumber[1] = (Button) findViewById(R.id.button1);
		buttonNumber[2] = (Button) findViewById(R.id.button2);
		buttonNumber[3] = (Button) findViewById(R.id.button3);
		buttonNumber[4] = (Button) findViewById(R.id.button4);
		buttonNumber[5] = (Button) findViewById(R.id.button5);
		buttonNumber[6] = (Button) findViewById(R.id.button6);
		buttonNumber[7] = (Button) findViewById(R.id.button7);
		buttonNumber[8] = (Button) findViewById(R.id.button8);
		buttonNumber[9] = (Button) findViewById(R.id.button9);

		for (int i = 0; i < 10; i++) {
			buttonNumber[i].setOnClickListener(btnClickListener);
		}
		finishButton = (Button) findViewById(R.id.button12);
		finishButton.setOnClickListener(btnClickListener);
		nextButton = (Button) findViewById(R.id.button10);
		nextButton.setOnClickListener(btnClickListener);
		resetButton = (Button) findViewById(R.id.button13);
		resetButton.setOnClickListener(btnClickListener);
		//

		password_EditText = (EditText) findViewById(R.id.password_EditText);
		password_EditText.setEnabled(false);

		drawableImage = new int[4];

		drawableImage[1] = R.drawable.red;
		drawableImage[2] = R.drawable.yellow;
		drawableImage[3] = R.drawable.blue;

		imgView1.setImageResource(drawableImage[random1]);
		imgView2.setImageResource(drawableImage[random2]);
		imgView3.setImageResource(drawableImage[random3]);
	}
}