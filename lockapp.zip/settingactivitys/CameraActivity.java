package com.lockapp.settingactivitys;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EventObject;

import com.lockapp.*;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;

public class CameraActivity extends Activity{

	public static String IMAGE_FILE ;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_camera);
		long time = System.currentTimeMillis();
		Date date = new Date(time);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a");
		
		IMAGE_FILE = sdf.format(date);
		
		final CameraSurfaceView cameraView = new CameraSurfaceView(getApplicationContext());
		
		FrameLayout previewFrame = (FrameLayout) findViewById(R.id.previewFrame);
		previewFrame.addView(cameraView);;
		Button saveBtn = (Button) findViewById(R.id.saveBtn);
		String str;
		int rand1, rand2;
		rand1 = (int)(Math.random()*100)+1;
		rand2 = (int)(Math.random()*100)+1;
		str = ("Solve this\n" + "then unlock\n" + rand1 + " + " + rand2 + " =  ____");
		saveBtn.setText(str);
		
		
		saveBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				cameraView.capture(new Camera.PictureCallback() {
					@Override
					public void onPictureTaken(byte[] data, Camera camera) {
						// TODO Auto-generated method stub
						try {
							Bitmap bitmap = BitmapFactory.decodeByteArray(data,
									0, data.length);
							String outUriStr = MediaStore.Images.Media
									.insertImage(getContentResolver(), bitmap,
											"Captured Image",
											"Caputred Image using Camera.");
							if (outUriStr == null) {
								Log.d("SampleCapture", "Image insert failed.");
								return;
							} else {
								Uri outUri = Uri.parse(outUriStr);
								sendBroadcast(new Intent(
										Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
										outUri));
							}
							Toast.makeText(getApplicationContext(),	"�� ������>3<",
									Toast.LENGTH_SHORT).show();
							finish();
							
						} catch (Exception e) {
							Log.e("SampleCapture", "Failed to insert image.", e);
						}
					}
				});
			}
		});	
	}

	public class CameraSurfaceView extends SurfaceView implements
			SurfaceHolder.Callback {
		private SurfaceHolder mHolder;
		private Camera camera = null;

		public CameraSurfaceView(Context context) {
			super(context);

			mHolder = getHolder();
			mHolder.addCallback(this);
			mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void surfaceChanged(SurfaceHolder holder, int format, int width,
				int height) {
			// TODO Auto-generated method stub
			camera.startPreview();
		}

		@Override
		public void surfaceCreated(SurfaceHolder holder) {
			// TODO Auto-generated method stub
			if (camera != null) {
				camera.stopPreview();
				camera.release();
				camera = null;
			}
			camera = Camera.open(CameraInfo.CAMERA_FACING_FRONT);		
			camera.setDisplayOrientation(90);
			try {
				camera.setPreviewDisplay(mHolder);
			} catch (Exception e) {
				Log.e("CameraSurfaceView", "Failed to set camera preview.", e);
			}
		}

		@Override
		public void surfaceDestroyed(SurfaceHolder holder) {
			// TODO Auto-generated method stub
			camera.stopPreview();
			camera.release();
			camera = null;
		}

		public boolean capture(Camera.PictureCallback handler) {
			if (camera != null) {
				camera.takePicture(null, null, handler);
				return true;
			} else {
				return false;
			}
		}
	}
}