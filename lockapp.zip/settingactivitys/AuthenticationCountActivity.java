package com.lockapp.settingactivitys;

import java.util.ArrayList;

import com.lockapp.R;
import com.lockapp.database.PasswordDB;
import com.lockapp.entity.Password;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class AuthenticationCountActivity extends Activity implements
		OnItemSelectedListener {

	private PasswordDB dao;
	private ArrayList<String> arrayList;
	private String count;
	private Spinner spinner;
	private Button finishButton;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.layout_authentication_count);
		finishButton = (Button) findViewById(R.id.countFinishButton);
		finishButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dao = new PasswordDB(v.getContext());
				Password password = new Password();
				password.setAuthenticationCount(Integer.parseInt(count));

				Toast.makeText(v.getContext(),
						"Count : " + password.getAuthenticationCount(),
						Toast.LENGTH_SHORT).show();
				dao.updateCount(password);
				finish();
			}
		});
		spinner = (Spinner) findViewById(R.id.spinner);
		spinner.setPrompt("���� Ƚ�� ����");
		arrayList = new ArrayList<String>();
		arrayList.add("1");
		arrayList.add("2");
		arrayList.add("3");
		arrayList.add("4");
		arrayList.add("5");
		arrayList.add("6");

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, arrayList);
		Spinner sp = (Spinner) this.findViewById(R.id.spinner);
		sp.setPrompt("�����õ� ȸ�� ����");

		sp.setAdapter(adapter);
		sp.setOnItemSelectedListener((OnItemSelectedListener) this);
	}

	@Override
	public void onItemSelected(AdapterView<?> adapterView, View v,
			int position, long id) {
		// TODO Auto-generated method stub
		Toast.makeText(this, arrayList.get(position), Toast.LENGTH_SHORT).show();
		count = arrayList.get(position);

	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
	}
}