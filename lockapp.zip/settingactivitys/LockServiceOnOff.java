package com.lockapp.settingactivitys;

import com.lockapp.R;
import com.lockapp.database.PasswordCursor;
import com.lockapp.database.PasswordDB;
import com.lockapp.entity.Password;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class LockServiceOnOff extends Activity {

	private PasswordDB dao;
	private PasswordCursor cursor;

	private Button setOnButton;
	private Button setOffButton;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_lockserviceonoff);
		dao = new PasswordDB(this);
		cursor = dao.getPassword();

		setOnButton = (Button) findViewById(R.id.allLockSetOnButton);
		setOnButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (cursor != null || cursor.getCount() != 0)
					dao.updateLockServiceOn();
			}
		});
		setOffButton = (Button) findViewById(R.id.allLockSetOffButton);
		setOffButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (cursor != null || cursor.getCount() != 1)
					dao.updateLockServiceOff();
			}
		});
	}
}
