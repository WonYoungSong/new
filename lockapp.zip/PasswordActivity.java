package com.lockapp;

import com.lockapp.database.BlockCursor;
import com.lockapp.database.BlockDAO;
import com.lockapp.database.PasswordCursor;
import com.lockapp.database.PasswordDB;
import com.lockapp.entity.Block;
import com.lockapp.entity.Password;
import com.lockapp.services.LockService;
import com.lockapp.settingactivitys.CameraActivity;
import com.lockapp.settingactivitys.DeleteActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.*;
import android.widget.*;

import java.util.Random;

public class PasswordActivity extends Activity {

	private int idBlockParameter;
	private PasswordDB dao;
	private PasswordCursor passwordCursor;

	private BlockDAO daoBlock;
	private BlockCursor blockCursor;

	int firstPasswordColor = 0, secondPasswordColor = 0,
			thirdPasswordColor = 0, lastPasswordColor = 0;

	private int authenticationCount = 0;

	ImageView imgView1;
	ImageView imgView2;
	ImageView imgView3;

	String str;
	int stringPointer = 0;
	int colorCount = 0;

	String[] passwordDigit;
	int[] passwordColor;

	EditText password_EditText;
	int random1;
	int random2;
	int random3;
	int[] drawableImage;
	Button[] buttonNumber;
	Button finishButton;
	Button nextButton;
	Button resetButton;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_password);

		dao = new PasswordDB(getApplicationContext());
		daoBlock = new BlockDAO(getApplicationContext());
		passwordCursor = dao.getPassword();
		authenticationCount = passwordCursor.getAuthenticationCount();

		passwordDigit = new String[4];
		passwordColor = new int[4];
		random1 = (int) (Math.random() * 3) + 1;
		random2 = (int) (Math.random() * 3) + 1;

		while (random1 == random2) {
			random2 = (int) (Math.random() * 3) + 1;
		}
		random3 = (int) (Math.random() * 3) + 1;
		while (random1 == random3 || random2 == random3) {
			random3 = (int) (Math.random() * 3) + 1;
		}

		dao = new PasswordDB(this);
		str = "";

		imgView1 = (ImageView) findViewById(R.id.imgview1);
		imgView2 = (ImageView) findViewById(R.id.imgview2);
		imgView3 = (ImageView) findViewById(R.id.imgview3);

		buttonNumber = new Button[10];
		buttonNumber[0] = (Button) findViewById(R.id.button11);
		buttonNumber[1] = (Button) findViewById(R.id.button1);
		buttonNumber[2] = (Button) findViewById(R.id.button2);
		buttonNumber[3] = (Button) findViewById(R.id.button3);
		buttonNumber[4] = (Button) findViewById(R.id.button4);
		buttonNumber[5] = (Button) findViewById(R.id.button5);
		buttonNumber[6] = (Button) findViewById(R.id.button6);
		buttonNumber[7] = (Button) findViewById(R.id.button7);
		buttonNumber[8] = (Button) findViewById(R.id.button8);
		buttonNumber[9] = (Button) findViewById(R.id.button9);
		
		for (int i = 0; i < 10; i++) {
			buttonNumber[i].setOnClickListener(btnClickListener);
		}
		finishButton = (Button) findViewById(R.id.button12);
		finishButton.setOnClickListener(btnClickListener);
		nextButton = (Button) findViewById(R.id.button10);
		nextButton.setOnClickListener(btnClickListener);
		resetButton = (Button) findViewById(R.id.button13);
		resetButton.setOnClickListener(btnClickListener);

		password_EditText = (EditText) findViewById(R.id.password_EditText);	
		password_EditText.setEnabled(false);

		drawableImage = new int[4];

		// 1은 red
		// 2은 yellow
		// 3는 blue
		drawableImage[1] = R.drawable.red;
		drawableImage[2] = R.drawable.yellow;
		drawableImage[3] = R.drawable.blue;

		imgView1.setImageResource(drawableImage[random1]);
		imgView2.setImageResource(drawableImage[random2]);
		imgView3.setImageResource(drawableImage[random3]);
		
		Intent intent = getIntent();
		idBlockParameter = intent.getExtras().getInt("block");
	}

	private void setPassword(int number) {
		if (stringPointer < 4) {
			colorCount++;
			passwordDigit[stringPointer] = Integer.toString(number);
			passwordColor[stringPointer] = colorCount;
		}
	}

	private int makePassword(int color) {

		int num = 0;
		int tempColor = color % 3;
		if (tempColor == 1) {
			num = random1;
		} else if (tempColor == 2) {
			num = random2;
		} else {
			num = random3;
		}
		return num;
	}

	private Button.OnClickListener btnClickListener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.button11:
				Toast.makeText(v.getContext(), "0", Toast.LENGTH_SHORT).show();
				str += "0";
				password_EditText.setText(str);
				setPassword(0);
				break;
				
			case R.id.button1:
				Toast.makeText(v.getContext(), "1", Toast.LENGTH_SHORT).show();
				str += "1";
				password_EditText.setText(str);
				setPassword(1);
				break;
				
			case R.id.button2:		
				Toast.makeText(v.getContext(), "2", Toast.LENGTH_SHORT).show();
				str += "2";
				password_EditText.setText(str);
				setPassword(2);
				break;
				
			case R.id.button3:
				Toast.makeText(v.getContext(), "3", Toast.LENGTH_SHORT).show();
				str += "3";
				password_EditText.setText(str);
				setPassword(3);
				break;
				
			case R.id.button4:
				Toast.makeText(v.getContext(), "4", Toast.LENGTH_SHORT).show();
				str += "4";
				password_EditText.setText(str);
				setPassword(4);
				break;
				
			case R.id.button5:
				Toast.makeText(v.getContext(), "5", Toast.LENGTH_SHORT).show();
				str += "5";
				password_EditText.setText(str);
				setPassword(5);
				break;
				
			case R.id.button6:
				Toast.makeText(v.getContext(), "6", Toast.LENGTH_SHORT).show();
				str += "6";
				password_EditText.setText(str);
				setPassword(6);
				break;
				
			case R.id.button7:
				Toast.makeText(v.getContext(), "7", Toast.LENGTH_SHORT).show();
				str += "7";
				password_EditText.setText(str);
				setPassword(7);
				break;
				
			case R.id.button8:
				Toast.makeText(v.getContext(), "8", Toast.LENGTH_SHORT).show();
				str += "8";
				password_EditText.setText(str);
				setPassword(8);
				break;
				
			case R.id.button9:
				Toast.makeText(v.getContext(), "9", Toast.LENGTH_SHORT).show();
				str += "9";
				password_EditText.setText(str);
				setPassword(9);
				break;
			case R.id.button10:

				Toast.makeText(v.getContext(), "Next", Toast.LENGTH_SHORT).show();
				str += "";
				colorCount = 0;
				if (stringPointer < 4) {
					stringPointer++;
				}
				break;

			case R.id.button12:
				Toast.makeText(v.getContext(), "Finish", Toast.LENGTH_SHORT).show();
				if (passwordDigit[0] != null && passwordDigit[1] != null
						&& passwordDigit[2] != null && passwordDigit[3] != null
						&& passwordColor[0] != 0 && passwordColor[1] != 0
						&& passwordColor[2] != 0 && passwordColor[3] != 0) {
					Password password = new Password();
					password.setFirstPassword(Integer.parseInt(passwordDigit[0]));
					password.setSecondPassword(Integer.parseInt(passwordDigit[1]));
					password.setThirdPassword(Integer.parseInt(passwordDigit[2]));
					password.setLastPassword(Integer.parseInt(passwordDigit[3]));
					password.setFirstPasswordColor(makePassword(passwordColor[0]));
					password.setSecondPasswordColor(makePassword(passwordColor[1]));
					password.setThirdPasswordColor(makePassword(passwordColor[2]));
					password.setLastPasswordColor(makePassword(passwordColor[3]));

					if (passwordCursor != null 	|| passwordCursor.getCount() != 0) {
						for (int i = 0; i < passwordCursor.getCount(); i++) {
							Password savedPassword = new Password();

							savedPassword.setFirstPassword(passwordCursor.getDigitFirst());
							savedPassword.setSecondPassword(passwordCursor.getDigitSecond());
							savedPassword.setThirdPassword(passwordCursor.getDigitThird());
							savedPassword.setLastPassword(passwordCursor.getDigitLast());
							savedPassword.setFirstPasswordColor(passwordCursor.getColorFirst());
							savedPassword.setSecondPasswordColor(passwordCursor.getColorSecond());
							savedPassword.setThirdPasswordColor(passwordCursor.getColorThird());
							savedPassword.setLastPasswordColor(passwordCursor.getColorLast());

							if (password.getFirstPassword() == savedPassword.getFirstPassword()
									&& password.getSecondPassword() == savedPassword.getSecondPassword()
									&& password.getThirdPassword() == savedPassword.getThirdPassword()
									&& password.getLastPassword() == savedPassword.getLastPassword()
									&& password.getFirstPasswordColor() == savedPassword.getFirstPasswordColor()
									&& password.getSecondPasswordColor() == savedPassword.getSecondPasswordColor()
									&& password.getThirdPasswordColor() == savedPassword.getThirdPasswordColor()
									&& password.getLastPasswordColor() == savedPassword.getLastPasswordColor()) {
								blockCursor = daoBlock.getBlockId(idBlockParameter);
								Block blockAlterar = new Block();
								blockAlterar.setIdBlock(blockCursor.getIdBlock());
								blockAlterar.setLibrary(1);
								daoBlock.update(blockAlterar);
								daoBlock.getAll();
								Toast.makeText(v.getContext(), "잠금해제", Toast.LENGTH_SHORT).show();
								finish();
								break;
							}else {
								if (--authenticationCount <= 0) {
									startActivity(new Intent(v.getContext(),CameraActivity.class));
								}
							}
						}
					}else {
						if (--authenticationCount <= 0) {
							startActivity(new Intent(v.getContext(),CameraActivity.class));
						}
					}
				} else {
					if (--authenticationCount <= 0) {
						startActivity(new Intent(v.getContext(),CameraActivity.class));
					}
				}
				break;

			case R.id.button13:
				Toast.makeText(v.getContext(), "reset", Toast.LENGTH_SHORT).show();
				str = " ";
				password_EditText.setText(str);
				colorCount = 0;
				stringPointer = 0;
				break;
			}
		}
	};
}