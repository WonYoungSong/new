package com.lockapp.broadcastreceivers;

import com.lockapp.services.LockService;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.*;
import android.widget.Toast;

public class LockReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		Intent appService = new Intent(context, LockService.class);
		Log.v("LockReceiver class", "LockReceiver class");
		context.startService(appService);
	}
}