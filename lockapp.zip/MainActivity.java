package com.lockapp;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.*;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;

import com.lockapp.adapter.ListAplicationAdapter;
import com.lockapp.adapter.ListAplicationLockedAdapter;
import com.lockapp.database.BlockCursor;
import com.lockapp.database.BlockDAO;
import com.lockapp.database.PasswordCursor;
import com.lockapp.database.PasswordDB;
import com.lockapp.entity.Block;
import com.lockapp.services.LockService;
import com.lockapp.settingactivitys.*;

public class MainActivity extends FragmentActivity {

	SectionsPagerAdapter mSectionsPagerAdapter;
	ViewPager mViewPager;

	private static List<Block> allApplicationList;
	private static List<Block> lockedApplicationList;
	private static PackageManager pm;

	private static BlockDAO dao;
	private static BlockCursor cursor;
	private static PasswordDB pwdDB;
	private static PasswordCursor passwordCursor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.v("MainActivity class", "MainActivity class");
		// case didn't set password then make password.
		pwdDB = new PasswordDB(this);
		passwordCursor = pwdDB.getPassword();

		setContentView(R.layout.layout_main);

		// Create the adapter that will return a fragment for each of the three
		// primary sections of the app.

		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager());

		// Set up the ViewPager with the sections adapter.
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);

		allApplicationList = new ArrayList<Block>();
		pm = getPackageManager();
		List<PackageInfo> listApps = pm.getInstalledPackages(0);
		for (PackageInfo info : listApps) {

			Block app = new Block();
			app.setNameApp(info.applicationInfo.loadLabel(getPackageManager()).toString());
			app.setPackageApp(info.packageName);
			app.setIconApp(info.applicationInfo.loadIcon(getPackageManager()));
			allApplicationList.add(app);

		}

		dao = new BlockDAO(this);
		lockedApplicationList = new ArrayList<Block>();
		sendLockedApplication();
		dao.close();
		cursor.close();

		startService(new Intent(this, LockService.class));
	}

	public static void sendLockedApplication() {
		lockedApplicationList.clear();
		cursor = dao.getAll();
		for (int i = 0; i < cursor.getCount(); i++) {
			cursor.moveToPosition(i);
			Block block = new Block();
			block.setNameApp(cursor.getNameApp());
			block.setPackageApp(cursor.getPackageApp());
			block.setIconApp(getDrawableFromBytes(cursor.getImgApp()));
			lockedApplicationList.add(block);
		}
	}

	public static Drawable getDrawableFromBytes(byte[] imageBytes) {
		if (imageBytes != null)
			return new BitmapDrawable(BitmapFactory.decodeByteArray(imageBytes,
					0, imageBytes.length));
		else
			return null;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_principal, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.listmessagemenu:
			startActivity(new Intent(this, ListMessageActivity.class));
			overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
			break;
		case R.id.environmentSetting:
			// startActivity(new Intent(this,temp.class));
			Toast.makeText(this, "만든사람: 서연희, 송원영", Toast.LENGTH_LONG).show();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	public class SectionsPagerAdapter extends FragmentPagerAdapter {
		Fragment fragment;

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			// getItem is called to instantiate the fragment for the given page.
			// Return a DummySectionFragment (defined as a static inner class
			// below) with the page number as its lone argument.
			fragment = new DummySectionFragment();
			Bundle args = new Bundle();
			args.putInt(DummySectionFragment.ARG_SECTION_NUMBER, position + 1);
			fragment.setArguments(args);
			return fragment;
		}

		@Override
		public int getCount() {
			return 3;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			switch (position % 3) {
			case 0:
				return getString(R.string.title_section1).toUpperCase();
			case 1:
				return getString(R.string.title_section2).toUpperCase();
			case 2:
				return getString(R.string.title_section3).toUpperCase();
			}
			return null;
		}
	}

	public static class DummySectionFragment extends Fragment {
		
		public static final String ARG_SECTION_NUMBER = "section_number";
		public DummySectionFragment() {
		}
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View view = null;
			if (getArguments().getInt(ARG_SECTION_NUMBER) == 1) {
				view = inflater.inflate(R.layout.layout_lista_selected, null);
				ListView listViewAppsLocked = (ListView) view.findViewById(R.id.listViewBloqueados);

				sendLockedApplication();
				ListAplicationLockedAdapter adapter = new ListAplicationLockedAdapter(getActivity(), lockedApplicationList);
				listViewAppsLocked.setAdapter(adapter);
				listViewAppsLocked.setOnItemLongClickListener(new OnItemLongClickListener() {

							@Override
							public boolean onItemLongClick(AdapterView<?> adapterView, View v,	final int position, long id) {
								// TODO Auto-generated method stub
								AlertDialog.Builder alt_bid = new AlertDialog.Builder(v.getContext());
								alt_bid.setMessage("Do you wanna delete?").setCancelable(false).setPositiveButton(
												"YES",new DialogInterface.OnClickListener() {
												@Override
												public void onClick(	DialogInterface dialog,int which) {
													Block block = lockedApplicationList.get(position);
													
													dao.delete(block);
												}
											})
											.setNegativeButton(
											"No",
											new DialogInterface.OnClickListener() {

												@Override
												public void onClick(
														DialogInterface dialog,
														int which) {													
													dialog.cancel();												
												}
											});
							AlertDialog alert = alt_bid.create();
							alert.setTitle("Delete dialog");
							alert.setIcon(null);
							alert.show();
							return false;
							}
						});
			}
			if (getArguments().getInt(ARG_SECTION_NUMBER) == 2) {
				
				view = inflater.inflate(R.layout.layout_list_allapps, null);
				ListView listViewApps = (ListView) view.findViewById(R.id.listViewApps);
				ListAplicationAdapter adapter = new ListAplicationAdapter(getActivity(), allApplicationList);
				listViewApps.setAdapter(adapter);
				listViewApps.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> adapterView, View v,
							int position, long longId) {
						Block block = allApplicationList.get(position);						
						Bitmap bitmap = ((BitmapDrawable) block.getIconApp()).getBitmap();
						ByteArrayOutputStream stream = new ByteArrayOutputStream();
						bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
						byte[] bitmapdata = stream.toByteArray();
						block.setArrayImg(bitmapdata);
						block.setLibrary(0);
						dao.insert(block);
					}
				});
			}
			if (getArguments().getInt(ARG_SECTION_NUMBER) == 3) {
				view = inflater.inflate(R.layout.layout_environmentsettings,
						null);
				ListView settingList = (ListView) view
						.findViewById(R.id.environmentSettingList);
				ArrayList<String> list = new ArrayList<String>();

				list.add("전체 앱 잠금 설정");
				list.add("인증 시도 회수 설정");
				list.add("패스워드 설정");
				list.add("패스워드 변경");
				list.add("패스워드 해제");

				ArrayAdapter<String> adapter = new ArrayAdapter<String>(
						view.getContext(), android.R.layout.simple_list_item_1,list);
				settingList.setAdapter(adapter);
				settingList.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> adapterView, View v,
							int position, long id) {
						// TODO Auto-generated method stub
						passwordCursor = null;
						passwordCursor = pwdDB.getPassword();

						switch (position) {
						case 0:
							if (passwordCursor == null || passwordCursor.getCount() == 0) {
								Toast.makeText(v.getContext(), "비밀번호가 없습니다. 설정해주세요!",	Toast.LENGTH_SHORT).show();
							} else {
								startActivity(new Intent(v.getContext(),AuthenticateLockServiceOnOff.class));
							}
							break;
							
						case 1:
							if (passwordCursor == null || passwordCursor.getCount() == 0) {
								Toast.makeText(v.getContext(),	"비밀번호가 없습니다. 설정해주세요!",Toast.LENGTH_SHORT).show();
							} else {
								startActivity(new Intent(v.getContext(),	AuthenticateAuthenticationCountActivity.class));
							}
							break;
							
						case 2:
							// set password
							if (passwordCursor == null || passwordCursor.getCount() == 0) {
								startActivity(new Intent(v.getContext(),
										DefinePasswordActivity.class));
							} else {
								Toast.makeText(v.getContext(), "이미 비밀번호가 있습니다",	Toast.LENGTH_SHORT).show();
							}
							break;
						case 3:
							// change password
							if (passwordCursor == null || passwordCursor.getCount() == 0) {
								Toast.makeText(v.getContext(),
										"비밀번호가 없습니다. 설정해주세요!",
										Toast.LENGTH_SHORT).show();
							} else {
								startActivity(new Intent(v.getContext(),	UpdatePasswordActivity.class));
							}
							break;
							
						case 4:
							if (passwordCursor == null
									|| passwordCursor.getCount() == 0) {
								Toast.makeText(v.getContext(), 	"비밀번호가 없습니다. 설정해주세요!", Toast.LENGTH_SHORT).show();
							} else {
								startActivity(new Intent(v.getContext(),	DeletePasswordActivity.class));
							}
							break;
						}
					}
				});
			}

			return view;
		}
	}

}
