package com.lockapp.adapter;

import java.util.List;

import android.content.Context;
import android.util.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.lockapp.R;
import com.lockapp.entity.Block;

public class ListAplicationAdapter extends BaseAdapter {

	private Context context;
	private List<Block> listApps;

	public ListAplicationAdapter(Context context, List<Block> listApps) {
		Log.v("ListAplicationAdapter class", "ListAplicationAdapter class");
		this.context = context;
		this.listApps = listApps;
	}

	@Override
	public int getCount() {
		return listApps.size();
	}

	@Override
	public Object getItem(int position) {
		return listApps.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Block app = listApps.get(position);
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(
				R.layout.layout_adapter_list_allapplication, null);

		TextView textViewNomeApp = (TextView) view
				.findViewById(R.id.textViewNomeApp);
		TextView textViewPacoteApp = (TextView) view
				.findViewById(R.id.textViewPacoteApp);
		ImageView imageViewApp = (ImageView) view
				.findViewById(R.id.imageViewImagemApp);

		textViewNomeApp.setText(app.getNameApp());
		textViewPacoteApp.setText(app.getPackageApp());
		imageViewApp.setImageDrawable(app.getIconApp());

		return view;
	}

}