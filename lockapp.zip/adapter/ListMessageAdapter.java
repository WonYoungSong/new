package com.lockapp.adapter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.lockapp.R;
import com.lockapp.entity.Mensagem;

import android.content.Context;
import android.util.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListMessageAdapter extends BaseAdapter {

	private Context context;
	private List<Mensagem> listMensagem;

	public ListMessageAdapter(Context context, List<Mensagem> listMensagem) {
		Log.v("ListMessageAdapter class", "ListMessageAdapter class");
		this.context = context;
		this.listMensagem = listMensagem;
	}

	@Override
	public int getCount() {
		return listMensagem.size();
	}

	@Override
	public Object getItem(int position) {
		return listMensagem.get(position);
	}

	@Override
	public long getItemId(int id) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater
				.inflate(R.layout.layout_adapter_list_message, null);

		TextView textViewEndereco = (TextView) view
				.findViewById(R.id.textViewMessageAddr);
		TextView textViewCorpoMensagem = (TextView) view
				.findViewById(R.id.textViewCorpoMensagem);
		TextView textViewData = (TextView) view
				.findViewById(R.id.textViewDataMensagem);
		TextView textViewPasta = (TextView) view
				.findViewById(R.id.textViewPastaMensagem);

		Mensagem mensagem = listMensagem.get(position);
		textViewEndereco.setText(mensagem.getEndereco());
		textViewCorpoMensagem.setText(mensagem.getMensagem());
		textViewPasta.setText(mensagem.getFolderName());

		Date date = new Date(Long.parseLong(mensagem.getData()));
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		textViewData.setText(format.format(date));

		return view;
	}

}