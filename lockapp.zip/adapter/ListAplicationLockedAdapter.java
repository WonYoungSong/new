package com.lockapp.adapter;

import java.util.List;

import com.lockapp.R;
import com.lockapp.entity.Block;

import android.content.Context;
import android.util.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListAplicationLockedAdapter extends BaseAdapter {

	private Context context;
	private List<Block> listBlock;

	public ListAplicationLockedAdapter(Context context, List<Block> listBlock) {
		Log.v("ListApplicationLockedAdapter class",
				"ListApplicationLockedAdapter class");
		this.context = context;
		this.listBlock = listBlock;
	}

	@Override
	public int getCount() {
		return listBlock.size();
	}

	@Override
	public Object getItem(int position) {
		return listBlock.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Block block = listBlock.get(position);

		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(
				R.layout.layout_adapter_list_selectedapplication, null);

		TextView textViewNomeApp = (TextView) view
				.findViewById(R.id.textViewNomeAppBlock);
		TextView textViewPacoteApp = (TextView) view
				.findViewById(R.id.textViewPacoteAppBlock);
		ImageView imageViewApp = (ImageView) view
				.findViewById(R.id.imageViewImagemAppBlock);

		textViewNomeApp.setText(block.getNameApp());
		textViewPacoteApp.setText(block.getPackageApp());
		imageViewApp.setImageDrawable(block.getIconApp());

		return view;
	}

}