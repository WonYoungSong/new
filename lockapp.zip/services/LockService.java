package com.lockapp.services;

import java.util.List;
import com.lockapp.PasswordActivity;
import com.lockapp.database.BlockCursor;
import com.lockapp.database.BlockDAO;
import com.lockapp.database.PasswordCursor;
import com.lockapp.database.PasswordDB;
import com.lockapp.entity.Block;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

public class LockService extends Service{

	private Handler handler;
	private Thread thread;
	private Runnable runnable;
	boolean running;
	
	boolean blocked = true;
	
	private BlockDAO dao;
	private BlockCursor cursor;
	private Block blockGlobal;
	private Block blockGlobalLockApp;
	private String checaPackage = "";
	private String checaClass = "";
	private PasswordDB passwordDB;
	private PasswordCursor passwordCursor;
	int count ;
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onCreate() {
		
		dao = new BlockDAO(getApplicationContext());
		cursor = dao.getAll();
		passwordDB = new PasswordDB(this);
		running = true;
		handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				cursor = dao.getAll();
				ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
				List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(30);
				
				if(!checaClass.equals(tasks.get(0).baseActivity.flattenToShortString()) && !blocked){
					blockGlobalLockApp.setLibrary(0);
					dao.update(blockGlobalLockApp);
					blocked = true;
				}
				
				if(tasks.get(0).baseActivity.flattenToShortString().equals("com.lockapp/.PrincipalActivity") && cursor.getCount()!= 0){
				
					for(int i = 0; i < cursor.getCount(); i++){
						cursor.moveToPosition(i);						
						
						if(cursor.getPackageApp().equals(tasks.get(0).baseActivity.flattenToShortString()) && cursor.getLibrary() == 0 && blocked){
							checaClass = tasks.get(0).baseActivity.flattenToShortString();
							blocked = false;
							blockGlobalLockApp = new Block();
							blockGlobalLockApp.setIdBlock(cursor.getIdBlock());
							Intent intent = new Intent(getApplicationContext(), PasswordActivity.class);
							intent.putExtra("block", cursor.getIdBlock());
							intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

							startActivity(intent);
						}					
					}			
				}else{					
					if((!checaPackage.equals(tasks.get(0).baseActivity.getPackageName())) && (blockGlobal != null) && (!tasks.get(0).baseActivity.getPackageName().equals("com.lockapp"))){
						blockGlobal.setLibrary(0);
						dao.update(blockGlobal);
					}

					for(int i = 0; i < cursor.getCount(); i++){
						cursor.moveToPosition(i);
						if(cursor.getPackageApp().equals(tasks.get(0).baseActivity.getPackageName()) && cursor.getLibrary() == 0){
							checaPackage = tasks.get(0).baseActivity.getPackageName();
							blockGlobal = new Block();
							blockGlobal.setIdBlock(cursor.getIdBlock());

							Intent intent = new Intent(getApplicationContext(), PasswordActivity.class);
							intent.putExtra("block", cursor.getIdBlock());
							intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
							passwordCursor = passwordDB.getPassword();
							count = passwordCursor.getLockServiceOn();
							Log.v(" low ","count : "+count);
							if(passwordCursor != null && passwordCursor.getLockServiceOn() == 1)
								startActivity(intent);						
						}
					}
				}
			}
		};
		
		runnable = new Runnable() {
			
			@Override
			public void run() {
				 while(running){
		           try {
		            Thread.sleep(500);
		            handler.sendEmptyMessage(0);
	
			        } catch (InterruptedException e) {
			            e.printStackTrace();
			        } 
		        }
			}
		};
		
		thread = new Thread(runnable);
		thread.start();
	}
	
	@Override
	public void onDestroy() {
		running = false;
	}	
}