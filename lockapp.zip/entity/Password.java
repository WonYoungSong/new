package com.lockapp.entity;

public class Password {

	private int idPassword;
	private int firstPassword;
	private int secondPassword;
	private int thirdPassword;
	private int lastPassword;
	private int firstPasswordColor;
	private int secondPasswordColor;
	private int thirdPasswordColor;
	private int lastPasswordColor;

	private int authenticationCount;
	private int lockserviceOn;

	public int getIdPassword() {
		return idPassword;
	}

	public void setIdPassword(int idPassword) {
		this.idPassword = idPassword;
	}

	public int getFirstPassword() {
		return firstPassword;
	}

	public void setFirstPassword(int firstDigit) {
		this.firstPassword = firstDigit;
	}

	public int getSecondPassword() {
		return secondPassword;
	}

	public void setSecondPassword(int secondDigit) {
		this.secondPassword = secondDigit;
	}

	public int getThirdPassword() {
		return thirdPassword;
	}

	public void setThirdPassword(int thirdDigit) {
		this.thirdPassword = thirdDigit;
	}

	public int getLastPassword() {
		return lastPassword;
	}

	public void setLastPassword(int lastDigit) {
		this.lastPassword = lastDigit;
	}

	public int getFirstPasswordColor() {
		return firstPasswordColor;
	}

	public void setFirstPasswordColor(int color) {
		this.firstPasswordColor = color;
	}

	public int getSecondPasswordColor() {
		return secondPasswordColor;
	}

	public void setSecondPasswordColor(int color) {
		this.secondPasswordColor = color;
	}

	public int getThirdPasswordColor() {
		return thirdPasswordColor;
	}

	public void setThirdPasswordColor(int color) {
		this.thirdPasswordColor = color;
	}

	public int getLastPasswordColor() {
		return lastPasswordColor;
	}

	public void setLastPasswordColor(int color) {
		this.lastPasswordColor = color;
	}

	public int getAuthenticationCount() {
		return authenticationCount;
	}

	public void setAuthenticationCount(int authenticationCount) {
		this.authenticationCount = authenticationCount;
	}

	public void setLockServiceOn(int lockserviceOn) {
		this.lockserviceOn = lockserviceOn;
	}

	public int getLockServiceOn() {
		return this.lockserviceOn;
	}
}