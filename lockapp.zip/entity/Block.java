package com.lockapp.entity;

import android.graphics.drawable.Drawable;

public class Block {

	private int idBlock;
	private String nameApp;
	private String packageApp;
	private Drawable iconApp;
	private byte[] arrayImg;
	private int library;

	public int getIdBlock() {
		return idBlock;
	}

	public void setIdBlock(int idBlock) {
		this.idBlock = idBlock;
	}

	public String getNameApp() {
		return nameApp;
	}

	public void setNameApp(String nameApp) {
		this.nameApp = nameApp;
	}

	public String getPackageApp() {
		return packageApp;
	}

	public void setPackageApp(String packageApp) {
		this.packageApp = packageApp;
	}

	public Drawable getIconApp() {
		return iconApp;
	}

	public void setIconApp(Drawable iconApp) {
		this.iconApp = iconApp;
	}

	public byte[] getArrayImg() {
		return arrayImg;
	}

	public void setArrayImg(byte[] arrayImg) {
		this.arrayImg = arrayImg;
	}

	public int getLibrary() {
		return library;
	}

	public void setLibrary(int liberacao) {
		this.library = liberacao;
	}

}