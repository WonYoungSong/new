package com.lockapp.entity;

public class Mensagem {
	
	private String id;
	private String address;
	private String mensagem;
	private String estadoLeitura;
	private String data;
	private String folderName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEndereco() {
		return address;
	}

	public void setEndereco(String address) {
		this.address = address;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getEstadoLeitura() {
		return estadoLeitura;
	}

	public void setEstadoLeitura(String estadoLeitura) {
		this.estadoLeitura = estadoLeitura;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
}